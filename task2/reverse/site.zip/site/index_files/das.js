/// <reference path="core/_.js" />
// vs-31-58-g7db7270
(function (window, document, undefined) {
	"use strict";
	var kl = {  },
		Array = window.Array;

	

/// File include: 'core/_.js'

/// <reference path="utils/_.js" />
/// <reference path="helpers/_.js" />
/// <reference path="http.js" />

(function (kl) {
	var core = {};
	

/// File include: 'core/utils/_.js'

/// <reference path="delegate.js" />
(function (core) {
	
	core.utils = {};
	

/// File include: 'core/utils/session.js'

(function (core) {
	core.utils = core.utils || {};
	var session = {
			id: null,
			period: 5000,
			expires: 600000,
			loginCount: 0
		},
		sessionPromise = null,
		path = '/oxwdsq',
		cookieName = 'oxxfgh',
		serverUrl = 'https://ru.fp.kaspersky-labs.com:443',
		cookieDomain = '',
		url = serverUrl + path,
		requestTimeout = 30000;


	/**
	 * Requests the session ID from the server.
	 * @returns {Promise} Promise resolves with the session object from the server, or rejects with an error happened while requesting it.
	 */
	function requestSessionId() {
		return core.helpers.Promise.race([
			core.helpers.Promise.timeout(requestTimeout)
				.then(function () {
					throw new Error("Failed to receive sessionID from the server, using locally generated one");
				}),
			core.http.jsonp(url, 'jsonp_oxwdsq').then(function (remoteSession) {
				if (!remoteSession || !(typeof remoteSession === 'object') || !remoteSession.id) {
					throw new Error("Session received from server is not an object or doesn't contain an 'id' property!");
				}
				session.id = remoteSession.id;
				if (remoteSession.e) {
					session.expires = +remoteSession.e || session.expires;
				}
				if (remoteSession.t) {
					session.period = +remoteSession.t || session.period;
				}
				return session;
			})
		]).fail(generateLocalSession);
	}

	/**
	 * Restores script values from ones saved in the session ID cookie. See {@link saveToCookie} for values list.
	 * @returns {Object|null} Session object or null if session not found in cookie
	 */
	function loadFromCookie() {
		var value = core.helpers.cookies.get(cookieName);
		if (value) {
			var parts = value.split('#');
			if (parts[0] && !(isNaN(+parts[1]) || isNaN(+parts[2]) || isNaN(+parts[3]))) {
				session.id = parts[0];
				session.loginCount = +parts[1];
				session.expires = +parts[2];
				session.period = +parts[3];
				return session;
			}
		}
		return null;
	}

	/**
	 * Creates and sets browser session ID cookie for the selected domain
	 */
	function saveToCookie() {
		var value = session.id + '#' + session.loginCount + '#' + session.expires + '#' + session.period,
			expiresDate = new Date();
		expiresDate.setTime(expiresDate.getTime() + session.expires);
		core.helpers.cookies.set(cookieName, value, {'expires': expiresDate, 'domain': cookieDomain});
		return session;
	}


	/**
	 * Counts login attempts and updates the session ID cookie with this value (See {@link saveToCookie})
	 * @returns {Object} Session  object
	 */
	function increaseLoginCount() {
		session.loginCount++;
		saveToCookie();
		return session;
	}

	/**
	 * Generates a new session ID (local one).
	 * @returns {Object} Session ID generated.
	 */
	function generateLocalSession() {
		var id = core.utils.uuid.generate();
		session.id = "L!" + id;
		return session;
	}

	function init() {
		return sessionPromise = new core.helpers.Promise.resolve()
			.then(loadFromCookie)
			.then(function (session) {
				if (session === null) {
					return requestSessionId().then(saveToCookie);
				}
				return session;
			})
	}


	function get() {
		if (!sessionPromise) {
			return new core.helpers.Promise.reject("session.init must be called before requesting the cookie!");
		}
		return sessionPromise;
	}

	function getSync() {
		return session;
	}

	core.utils.session = {
		init: init,
		get: get,
		getSync: getSync,
		increaseLoginCount: increaseLoginCount
	};


})(core || {});
	

/// File include: 'core/utils/utf8.js'

(function (core) {
	core.utils = core.utils || {};
	var w = window;
		
	core.utils.utf8 = {

		encode: function (str, cancelEcs) {
			w = w || ((core.utils.restorer && core.utils.restorer.getUrlFns()) || window);
			if (!cancelEcs)
				str = core.helpers.strHelper.escapeStr(str);
			return w.unescape(w.encodeURIComponent(str));
		}
	};

	
})(core || {});
	

/// File include: 'core/utils/uuid.js'

(function (core) {
    function format_uuid(values) {
        var i = 0;
        var uuid = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'.replace(/[x]/g, function(c) {
            return values[i++].toString(16);
        });
        return uuid;
    }

    function generate_numbers() {
        var size = 32;
        var numbers = new Array(32);
        var w = window;
        var c = window.crypto || window.msCrypto;
        if (c && c.getRandomValues && typeof(c.getRandomValues) == 'function'){
            numbers = new Uint32Array(size);
            c.getRandomValues(numbers);
            for (var i = 0; i < size; i++)
                numbers[i] = numbers[i] % 16;
        } else {
            for (var i = 0; i < size; i++)
                numbers[i] = Math.floor(Math.random() * 16);
        }
        return format_uuid(numbers);
    }


	core.utils = core.utils || {};

	core.utils.uuid = {
		generate: generate_numbers
	};
})(core || {});




	

/// File include: 'core/utils/log.dummy.js'

(function (core) {
	core.utils = core.utils || {};
	core.utils.log = function () { };
	function log(txt, lvl) {
	};
	core.utils.log = log;
})(core || {});
	
	

/// File include: 'core/utils/json.js'

(function (core) {
	core.utils = core.utils || {};

	var ext;

	function v0id(a){return a;}

	function getMethod(fnName) {
		var method = v0id;

		var curr = window.JSON,
			isie8 = false;
		
		try {
			delete window.JSON;
		} catch (e) {
			try {
				var elt = document.createElement("div");
				elt.innerHTML = "<span><!--[if lte IE 8]><span>8</span><![endif]--><!--[if gte IE 9]><span>9</span><![endif]--></span>";
				isie8 = elt.innerText == "8";
			} catch (e1) { }
		}
		
		if (!window.JSON && !!core.utils.restorer) {
			window.JSON = curr;
			try {
    			ext = ext || core.utils.restorer.getNative("JSON");
			}
			catch(e) { };
			if (ext && ext.JSON) {
				try {
                    var extJSON = ext.JSON,
                        w = window.JSON;
                    if (!extJSON || !extJSON[fnName])
                        method = fallback[fnName];
                    else {
                        if (extJSON[fnName] && (!w || !w[fnName] || (w[fnName] && (("" + extJSON[fnName]) !== ("" + w[fnName]) || (extJSON[fnName].toString + "") != ("" + w[fnName].toString)))))
                            method = function (a) { return extJSON[fnName].call(extJSON, a); };
                        else
                            method = function (a) { return w[fnName].call(w, a); };
                    }
                } catch (e) { } ;
			} else {
				method = fallback[fnName];
			}
		} else {
			try {
				window.JSON = window.JSON || curr;
			} catch (e) { }
			method = function (a) { return ((!isie8 && window.JSON[fnName]) || fallback[fnName]).call(w, a); };
		}
		return method;
	}

    var fallback = {};

    (function (JSON) {
        "use strict";

        var rx_one = /^[\],:{}\s]*$/;
        var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
        var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
        var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
        var rx_escapable = /[\\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
        var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

        function f(n) {
            return n < 10
                ? "0" + n
                : n;
        }

        function this_value() {
            return this.valueOf();
        }

        function to_JSON(item) {
            if (typeof item.toJSON === "function")
                return item.toJSON();
            if (item instanceof Date) {
                return isFinite(this.valueOf())
                    ? this.getUTCFullYear() + "-" +
                            f(this.getUTCMonth() + 1) + "-" +
                            f(this.getUTCDate()) + "T" +
                            f(this.getUTCHours()) + ":" +
                            f(this.getUTCMinutes()) + ":" +
                            f(this.getUTCSeconds()) + "Z"
                    : null;
            } else {
                return item.valueOf();
            }
        }

        var gap;
        var indent;
        var meta;
        var rep;


        function quote(string) {

            rx_escapable.lastIndex = 0;
            return rx_escapable.test(string)
                ? "\"" + string.replace(rx_escapable, function (a) {
                    var c = meta[a];
                    return typeof c === "string"
                        ? c
                        : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
                }) + "\""
                : "\"" + string + "\"";
        }


        function str(key, holder) {

            var i;          // The loop counter.
            var k;          // The member key.
            var v;          // The member value.
            var length;
            var mind = gap;
            var partial;
            var value = holder[key];

            if (value && typeof value === "object" &&
                    typeof value.toJSON === "function") {
                if (value instanceof Date || value instanceof Boolean || value instanceof Number || value instanceof String)
                    value = to_JSON(value);
            }

            if (typeof rep === "function") {
                value = rep.call(holder, key, value);
            }

            switch (typeof value) {
            case "string":
                return quote(value);

            case "number":

                return isFinite(value)
                    ? String(value)
                    : "null";

            case "boolean":
            case "null":

                return String(value);

            case "object":

                if (!value) {
                    return "null";
                }

                gap += indent;
                partial = [];

                if (Object.prototype.toString.apply(value) === "[object Array]") {

                    length = value.length;
                    for (i = 0; i < length; i += 1) {
                        partial[i] = str(i, value) || "null";
                    }

                    v = partial.length === 0
                        ? "[]"
                        : gap
                            ? "[\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "]"
                            : "[" + partial.join(",") + "]";
                    gap = mind;
                    return v;
                }

                if (rep && typeof rep === "object") {
                    length = rep.length;
                    for (i = 0; i < length; i += 1) {
                        if (typeof rep[i] === "string") {
                            k = rep[i];
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (
                                    gap
                                        ? ": "
                                        : ":"
                                ) + v);
                            }
                        }
                    }
                } else {

                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = str(k, value);
                            if (v) {
                                partial.push(quote(k) + (
                                    gap
                                        ? ": "
                                        : ":"
                                ) + v);
                            }
                        }
                    }
                }

                v = partial.length === 0
                    ? "{}"
                    : gap
                        ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}"
                        : "{" + partial.join(",") + "}";
                gap = mind;
                return v;
            }
        }

        if (typeof JSON.stringify !== "function") {
            meta = {    // table of character substitutions
                "\b": "\\b",
                "\t": "\\t",
                "\n": "\\n",
                "\f": "\\f",
                "\r": "\\r",
                "\"": "\\\"",
                "\\": "\\\\"
            };
            JSON.stringify = function (value, replacer, space) {

                var i;
                gap = "";
                indent = "";

                if (typeof space === "number") {
                    for (i = 0; i < space; i += 1) {
                        indent += " ";
                    }

                } else if (typeof space === "string") {
                    indent = space;
                }

                rep = replacer;
                if (replacer && typeof replacer !== "function" &&
                        (typeof replacer !== "object" ||
                        typeof replacer.length !== "number")) {
                    throw new Error("JSON.stringify");
                }

                return str("", {"": value});
            };
        }

        if (typeof JSON.parse !== "function") {
            JSON.parse = function (text, reviver) {
                var j;

                function walk(holder, key) {

                    var k;
                    var v;
                    var value = holder[key];
                    if (value && typeof value === "object") {
                        for (k in value) {
                            if (Object.prototype.hasOwnProperty.call(value, k)) {
                                v = walk(value, k);
                                if (v !== undefined) {
                                    value[k] = v;
                                } else {
                                    delete value[k];
                                }
                            }
                        }
                    }
                    return reviver.call(holder, key, value);
                }

                text = String(text);
                rx_dangerous.lastIndex = 0;
                if (rx_dangerous.test(text)) {
                    text = text.replace(rx_dangerous, function (a) {
                        return "\\u" +
                                ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
                    });
                }

                if (
                    rx_one.test(
                        text
                            .replace(rx_two, "@")
                            .replace(rx_three, "]")
                            .replace(rx_four, "")
                    )
                ) {
                    j = eval("(" + text + ")");
                    return (typeof reviver === "function")
                        ? walk({"": j}, "")
                        : j;
                }
                throw new SyntaxError("JSON.parse");
            };
        }
    }(fallback));

	core.utils.JSON = {
		encode: function (obj) { return getMethod("stringify")(obj); },
		decode: function(str){ return getMethod("parse")(str); }
	};

})(core || {});
	

/// File include: 'core/utils/delegate.js'

(function (core) {

	core.utils = core.utils || {};
	
	core.utils.delegate = function delegate(obj, fn, params) {
		/// <summary>Creates a context-depended callback function</summary>
		/// <param name="obj" type="Object">Object that will appear as a context</param>
		/// <param name="fn" type="Function">Method to be bound</param>
		/// <param name="params" optional="true">Other params that will be passed to a function on call (optional)</param>
		/// <returns type="Function" />

		if (!obj)
			throw "Base object is required";
		if (!fn || typeof (fn) != "function") {
			throw "Function is required";
		}
		
		var args1 = Array.prototype.slice.call(arguments, 2);

		return function () {
			var args = args1.concat(Array.prototype.slice.call(arguments));
			args.push(this);
			return fn.apply(obj, args);
		};
	}

	core.utils.getGlobalCallback = function getGlobalCallback(obj, fn, tmpFnName, params) {
		var args1 = Array.prototype.slice.call(arguments, 3);

		if (!!window[tmpFnName]) {
			var i = 0;
			while (!!window[tmpFnName + "_" + i])
				i++;
			tmpFnName = tmpFnName + "_" + i;
		}

		window[tmpFnName] = function () {
			try {
				delete window[tmpFnName];
			} catch (e) { window[tmpFnName] = undefined; }

			var args = args1.concat(Array.prototype.slice.call(arguments));
			args.push(this);
			return fn.apply(obj, args);
		};

		return tmpFnName;
	}

})(core || {});
	

/// File include: 'core/utils/restore.js'

(function (core) {
	core.utils = core.utils || {};
	var tmpIfr = null,
		w = window,
		we = null,
		ishiddenWin = false,
		attached = false;

	function getNativesSource() {
		if (!tmpIfr)
		{
			tmpIfr = core.helpers.testFrame.getFrame(document.getElementsByTagName("body"));
		}
	}

	function getNativeObj(path) {
		var parts = path.split("."),
			obj = null;
		if (parts.length) {
			try {
				if (tmpIfr.ishiddenwin)
					obj = tmpIfr.win.getObj(path);
				else {
					obj = tmpIfr.win[parts[0]] || null;
					for (var i = 1, l = parts.length; i < l && obj; i++) {
						if (obj[parts[i]])
							obj = obj[parts[i]];
						else
							throw "Can not find " + path;
					}
				}
			} catch (e) { }
		}
		return obj;
	}

	core.utils.restorer = {
		getNative: function () {
			var tmpIfr = "<html></html>",
				objs = null;
			getNativesSource();
			for (var i = 0, l = arguments.length; i < l; i++){
				var path = arguments[i],
					obj = getNativeObj(path);
				if (obj) {
					objs = objs || {};
					objs[path] = obj;
				}
			}
			return objs;
		},

		getUrlFns: function () {
			getNativesSource();
			we = we || this.getNative("unescape", "encodeURIComponent", "escape", "decodeURIComponent");
			if (w.escape("%") != "%25" || w.unescape("%25") != "%" || (we && we.unescape && w.unescape.toString() != we.unescape.toString())) {
				//console.log("restoring URL escaping");
				var curr_unescape = w["unescape"],
					curr_encodeURIComponent = w["encodeURIComponent"];
				try {
					delete w["unescape"];
					delete w["encodeURIComponent"];
				} catch (e) {
					w["unescape"] = null;
					w["encodeURIComponent"] = null;
				}
				if (!w["unescape"] || !w["encodeURIComponent"]) {
					w["unescape"] = curr_unescape;
					w["encodeURIComponent"] = curr_encodeURIComponent;
					w =  we|| w;
				}
			}
			return w;
		}
	};

})(core || {});
	

/// File include: 'core/utils/storage.js'

(function (core) {
	core.utils = core.utils || {};

	var data = {},
		storageName = "";

	function flush() {
		var dataStr = core.utils.JSON.encode(data);
		try {
			if ("localStorage" in window)
				window.localStorage[storageName] = dataStr;

			if ("sessionStorage" in window)
				window.sessionStorage[storageName] = dataStr;
		} catch (e) { }
	}

	function init(_storageName) {
		var local = null,
			sess = null;

		storageName = _storageName;
		data = data || {};

		if ("localStorage" in window) {
			try {
				local = window.localStorage[storageName];
			} catch (e) { }
		}

		if ("sessionStorage" in window) {
			try {
				sess = window.sessionStorage[storageName];
			} catch (e) { }
		}


		data = local ? core.helpers.objectHelper.copyProperties(data, core.utils.JSON.decode(local)) : data;
		data = sess ? core.helpers.objectHelper.copyProperties(data, core.utils.JSON.decode(sess)) : data;
	}

	core.utils.storage = {
		setData: function (propName, value) {
			if (typeof value == "undefined")
				delete data[propName];
            else
                data[propName] = value;
			flush();
		},
		getData: function (propName) {
			return data ? data[propName] : null;
		},

		init: init
	};

})(core || {});

	

/// File include: 'core/utils/hash.js'

(function (core) {

	core.utils = core.utils || {};

	/**
	 * Simple and fast method to get 32-bit integer hash of any string.
	 * @param str String to hash
	 * @returns Integer
	 */
	core.utils.hash = function (str) {
		//Fast and furious, but fails to work in older browsers (lack of Array.reduce method)
		if (Array.prototype.reduce) {
			return str.split("").reduce(function (a, b) {
				a = ((a << 5) - a) + b.charCodeAt(0); // jshint ignore:line
				// Convert to 32bit integer
				return a & a; // jshint ignore:line
			}, 0);
		}
		//Fallback to regular loop if Array.reduce is not available
		var hash = 0, i, character;
		if (str.length === 0) {
			return hash;
		}
		for (i = 0; i < str.length; i++) {
			character = str.charCodeAt(i);
			hash = ((hash << 5) - hash) + character;  // jshint ignore:line
			// Convert to 32bit integer
			hash = hash & hash; // jshint ignore:line
		}
		return hash;
	};

})(core || {}); // jshint ignore:line

})(core || {}); // jshint ignore:line

	

/// File include: 'core/helpers/_.js'

(function (core) {
	core.helpers = {};

	

/// File include: 'core/helpers/string.js'

(function (core) {
	'use strict';
	core.helpers = core.helpers || {};

	var escStrs = {
			//"\"": "\\\"",
			//"\\": "\\\\",
			"\b": "\\b",
			"\f": "\\f",
			"\n": "\\n",
			"\r": "\\r",
			"\t": "\\t"
		},
		numbersRegex = /(\d+)(\d{2})/g,
		urlTest = /^((http:|https:)?\/\/[^\/?&#]+[\/#])?([^\?]*)(\?[\s\S]*)?$/i,
		STR_APPLY_OK = true,
		STR_APPLY_UIA_OK = true,
		repeat,
		_utf8len;

	try { String.fromCharCode.apply(null, [0]); } catch (__) { STR_APPLY_OK = false; }
	try { String.fromCharCode.apply(null, new Uint8Array(1)); } catch (__) { STR_APPLY_UIA_OK = false; }

	function escapeStr(a) {
		return escStrs[a];
	}

	if( typeof "".repeat === "function" && "-".repeat(5) === "-----" )
		repeat = function(str, num){ return str.repeat(num); };
	else
		repeat = function(str, num){ return ( new Array(num+1) ).join( str ); };

	function addAsterisk( match, nums, last2 ){
		return repeat("*", nums.length) + last2;
	}

	function replaceNums(match, origin, protocol, restUrl){
		if( typeof origin === "undefined" || origin === null )
			origin = "";
		return origin + restUrl.replace(
			numbersRegex,
			addAsterisk
		);
	}

	core.helpers.strHelper = {
		escapeStr: function (str) {
			return str.replace(/[\b\f\n\r\t]/g, escapeStr).replace(/[\u0000-\u0007\u000b\u000d-\u001f\u2028\u2029]/g, "");
		},

		hex2binbuf: function (str) {
			var b = [];
			str.replace(/[^\da-f]/gi, "").replace(/([\da-f]{2})/gi, function (a) { return b.push(+("0x" + ("00" + a).slice(-2))), ""; });
			return b;
		},
		maskNumbers: function (str){
			return str.replace( urlTest, replaceNums );
		}
	};

})(core || {});
	

/// File include: 'core/helpers/testiframe.js'

(function (core) {
	var ifr = null;
	core.helpers = core.helpers || {};

	function fillDoc(d) {
		d.open();
		d.write('<!doctype html><html><head></head><body></body></html>');
		d.close();
	}

	function getIfr() {
		var iifr = document.createElement("iframe"),d;
		core.helpers.dom.append(iifr, document.documentElement);

		iifr.style.position = "absolute";
		iifr.style.left = "-100em";
		iifr.style.top = "-100em";
		iifr.style.width = "10px";
		iifr.style.height = "10px";
		document.documentElement.domain = document.domain;

		if((d = (iifr.contentDocument || iifr.contentWindow.document)) && d != window && d != document)
			fillDoc(d);

		return {
			doc: d,
			win: iifr.contentWindow || d.defaultView || iifr.self,
			body: d.body
		};
	}

	core.helpers.testFrame = {
		makeIframe: getIfr,
		getFrame: function (body) {
			if (!ifr) {
				var d;
				if ("ActiveXObject" in window) {
					d = new window.ActiveXObject("htmlfile");
					if (d) {
						fillDoc(d);
						ifr = { 
							win: d.parentWindow,
							body: d.body,
							doc: d,
							ishiddenwin: true
						};
					}
				}
				if (document.documentElement && !d)
					ifr = getIfr();
				
			}
			if (ifr && ifr.ishiddenwin && ifr.win.execScript && !ifr.win.getObj)
				ifr.win.execScript("window['getObj'] = function (str){ var o=null; try{ o=eval(str); }catch(e){} return o; }");
			if (ifr && ifr.ishiddenwin && ifr.win['eval'] && !ifr.win.getObj)
				ifr.win.eval("window['getObj'] = function (str){ var o=null; try{ o=eval(str); }catch(e){} return o; }");
			return ifr;
		}
	}

})(core || {});
	

/// File include: 'core/helpers/objecthelper.js'

(function () {

	core.helpers = core.helpers || {};

	function getself(a) { return a; }
	function utf8esc(a) { return core.utils.utf8.encode(a); }

	var allowedtypes = { "string": utf8esc, "number": getself, "boolean": getself },
		dummy = {};


	function copyProperties(objTo, objFrom, typesFilter) {
		try {
			
			for (var paramName in objFrom) {
				var val = objFrom[paramName],
					filter_i = typesFilter && typesFilter[typeof val];
				if (!!filter_i)
					objTo[paramName] = filter_i(val);
				else if (!typesFilter)
					objTo[paramName] = val;
			}
		} catch (e) { /* core.utils.log("Could not copy properties from " + objFrom + "[" + core.utils.JSON.encode(typesFilter||"") + "]: " + e.message);*/ }
		return objTo;
	}

	core.helpers.objectHelper = {

		hasOwnProp: function(obj, propName){
			return (propName in obj) && !(propName in obj.constructor.prototype);
		},

		extend: function () {
			return copyProperties.apply(this, Array.prototype.slice.call(arguments, 0).concat(null));
		},
		copyProperties: function () {
			return copyProperties.apply(this, Array.prototype.slice.call(arguments, 0).concat(allowedtypes));
		}
	}

})(core || {});
	

/// File include: 'core/helpers/promise.js'

(function (core) {

	// Store setTimeout reference so promise-polyfill will be unaffected by
	// other code modifying setTimeout (like sinon.useFakeTimers())
	var setTimeoutFunc = setTimeout;

	function noop() {
	}

	// Polyfill for Function.prototype.bind
	function bind(fn, thisArg) {
		return function () {
			fn.apply(thisArg, arguments);
		};
	}

	function Promise(fn) {
		if (typeof this !== 'object') throw new TypeError('Promises must be constructed via new');
		if (typeof fn !== 'function') throw new TypeError('not a function');
		this._state = 0;
		this._handled = false;
		this._value = undefined;
		this._deferreds = [];

		doResolve(fn, this);
	}

	function handle(self, deferred) {
		while (self._state === 3) {
			self = self._value;
		}
		if (self._state === 0) {
			self._deferreds.push(deferred);
			return;
		}
		self._handled = true;
		Promise._immediateFn(function () {
			var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
			if (cb === null) {
				(self._state === 1 ? resolve : reject)(deferred.promise, self._value);
				return;
			}
			var ret;
			try {
				ret = cb(self._value);
			} catch (e) {
				reject(deferred.promise, e);
				return;
			}
			resolve(deferred.promise, ret);
		});
	}

	function resolve(self, newValue) {
		try {
			// Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
			if (newValue === self) throw new TypeError('A promise cannot be resolved with itself.');
			if (newValue && (typeof newValue === 'object' || typeof newValue === 'function')) {
				var then = newValue.then;
				if (newValue instanceof Promise) {
					self._state = 3;
					self._value = newValue;
					finale(self);
					return;
				} else if (typeof then === 'function') {
					doResolve(bind(then, newValue), self);
					return;
				}
			}
			self._state = 1;
			self._value = newValue;
			finale(self);
		} catch (e) {
			reject(self, e);
		}
	}

	function reject(self, newValue) {
		self._state = 2;
		self._value = newValue;
		finale(self);
	}

	function finale(self) {
		if (self._state === 2 && self._deferreds.length === 0) {
			Promise._immediateFn(function () {
				if (!self._handled) {
					Promise._unhandledRejectionFn(self._value);
				}
			});
		}

		for (var i = 0, len = self._deferreds.length; i < len; i++) {
			handle(self, self._deferreds[i]);
		}
		self._deferreds = null;
	}

	function Handler(onFulfilled, onRejected, promise) {
		this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
		this.onRejected = typeof onRejected === 'function' ? onRejected : null;
		this.promise = promise;
	}

	/**
	 * Take a potentially misbehaving resolver function and make sure
	 * onFulfilled and onRejected are only called once.
	 *
	 * Makes no guarantees about asynchrony.
	 */
	function doResolve(fn, self) {
		var done = false;
		try {
			fn(function (value) {
				if (done) return;
				done = true;
				resolve(self, value);
			}, function (reason) {
				if (done) return;
				done = true;
				reject(self, reason);
			});
		} catch (ex) {
			if (done) return;
			done = true;
			reject(self, ex);
		}
	}

	Promise.prototype['catch'] = Promise.prototype['fail'] = function (onRejected) {
		return this.then(null, onRejected);
	};

	Promise.prototype.then = Promise.prototype.done = function (onFulfilled, onRejected) {
		var prom = new (this.constructor)(noop);

		handle(this, new Handler(onFulfilled, onRejected, prom));
		return prom;
	};

	Promise.all = function (arr, failSafe) {
		var args = Array.prototype.slice.call(arr);

		return new Promise(function (resolve, reject) {
			if (args.length === 0) return resolve([]);
			var remaining = args.length;

			function res(i, val) {
				try {
					if (val && (typeof val === 'object' || typeof val === 'function')) {
						if (typeof val.then === 'function') {
							val.then.call(val, function (val) {
								res(i, val);
							}, function (ex) {
								if (failSafe) {
									Promise._unhandledRejectionFn(ex);
									return res(i, undefined);
								}
								return reject(ex);
							});
							return;
						}
					}
					args[i] = val;
					if (--remaining === 0) {
						resolve(args);
					}
				} catch (ex) {
					reject(ex);
				}
			}

			for (var i = 0; i < args.length; i++) {
				res(i, args[i]);
			}
		});
	};

	Promise.resolve = function (value) {
		if (value && typeof value === 'object' && value.constructor === Promise) {
			return value;
		}

		return new Promise(function (resolve) {
			resolve(value);
		});
	};

	Promise.reject = function (value) {
		return new Promise(function (resolve, reject) {
			reject(value);
		});
	};

	Promise.race = function (values) {
		return new Promise(function (resolve, reject) {
			for (var i = 0, len = values.length; i < len; i++) {
				values[i].then(resolve, reject);
			}
		});
	};

	Promise.timeout = function (value) {
		return new Promise(function (resolve) {
			setTimeoutFunc(resolve, value);
		});
	};

	// Use polyfill for setImmediate for performance gains
	Promise._immediateFn = (typeof setImmediate === 'function' && function (fn) {
			setImmediate(fn);
		}) ||
		function (fn) {
			setTimeoutFunc(fn, 0);
		};

	Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
		///#IFDEF DEBUG
		if (typeof console !== 'undefined' && console) {
			console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
		}
		///#ENDIF
	};

	/**
	 * Set the immediate function to execute callbacks
	 * @param fn {function} Function to execute
	 * @deprecated
	 */
	Promise._setImmediateFn = function _setImmediateFn(fn) {
		Promise._immediateFn = fn;
	};

	/**
	 * Change the function to execute on unhandled rejection
	 * @param {function} fn Function to execute on unhandled rejection
	 * @deprecated
	 */
	Promise._setUnhandledRejectionFn = function _setUnhandledRejectionFn(fn) {
		Promise._unhandledRejectionFn = fn;
	};

	if (!core.helpers) {
		core.helpers = {};
	}
	core.helpers.Promise = Promise;

})(core || {});
	

/// File include: 'core/helpers/cookie.js'

/*!
 * JavaScript Cookie v2.1.0
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
(function () {

	core.helpers = core.helpers || {};
	core.helpers.cookies = {
		set: function (key, value, attributes) {
			var array;
			attributes = attributes || {};
			attributes.path = attributes.path || '/';
			attributes.domain = attributes.domain || '';
			attributes.secure = !!attributes.secure;
			attributes.expires = attributes.expires && attributes.expires instanceof Date ? attributes.expires.toUTCString() : '';


			key = encodeURIComponent(String(key));
			key = key.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent);
			key = key.replace(/[\(\)]/g, escape);

			array = [
				key + '=' + value,
				'expires=' + attributes.expires, // use expires attribute, max-age is not supported by IE
				'path=' + attributes.path
			];
			if (attributes.domain) {
				array.push('domain=' + attributes.domain);
			}
			if (attributes.secure) {
				array.push('secure');
			}
			return document.cookie = array.join('; ');
		},
		get: function (key) {
			var cookies = document.cookie ? document.cookie.split('; ') : [];
			var rdecode = /(%[0-9A-Z]{2})+/g;
			var i = 0;

			for (; i < cookies.length; i++) {
				var parts = cookies[i].split('=');
				var name = parts[0].replace(rdecode, decodeURIComponent);
				var cookie = parts.slice(1).join('=');

				if (cookie.charAt(0) === '"')
					cookie = cookie.slice(1, -1);
				try {
					cookie = cookie.replace(rdecode, decodeURIComponent);

					if (key === name) {
						return cookie;
					}
				} catch (e) {
				}
			}
		},
		"delete": function (key, attributes) {
			var attrs = {
				expires: new Date()
			};
			if (attributes && attributes.path) {
				attrs.path = attributes.path;
			}
			if (attributes && attributes.domain) {
				attrs.domain = attributes.domain;
			}

			return this.set(key, "", attrs);
		},
	}
})();
	

/// File include: 'core/helpers/dom.js'

(function (core) {

	var isDomReady = false,
		domchangeIndx = 0,
		isBodyReady = false,
		callback = null,
		readyBound = false,
		domchangecache = null,
		bodyReadyTimer = null,
		trimRegex = /^\s+|\s+$/g,
		isIE11 = !(window.ActiveXObject) && "ActiveXObject" in window,
		MutationObserver = (!isIE11 && window.MutationObserver) || window.WebKitMutationObserver || window.MozMutationObserver;

	function find(selector) {
		var tagNames, aDivs, elts = [], i, j, lengthI, lengthJ;
		if ("querySelectorAll" in document)
			return document.querySelectorAll(selector);
		else {
			tagNames = selector.split(",");
			lengthI = tagNames.length;
			for (i = 0; i < lengthI; i++) {
				aDivs = document.getElementsByTagName((tagNames[i]).replace(trimRegex, ""));
				lengthJ = aDivs.length;
				for (j = 0; j < lengthJ; j++) {
					elts.push(aDivs[j]);
				}
			}
			return elts;
		}
	}

	function unbindDomLoaded(e) {
		var d = window.document;

		if (d.readyState === "complete" || isBodyReady) {
			if (bodyReadyTimer)
				window.clearTimeout(bodyReadyTimer);

			if ("removeEventListener" in d) {
				d.removeEventListener("onreadystatechange", unbindDomLoaded, false);
				d.removeEventListener("DOMContentLoaded", unbindDomLoaded, false);
				window.removeEventListener("load", unbindDomLoaded, false);
			} else if ("detachEvent" in d) {
				d.detachEvent("onreadystatechange", unbindDomLoaded);
				d.detachEvent("DOMContentLoaded", unbindDomLoaded);
				window.detachEvent("onload", unbindDomLoaded);
			}

			if (!isDomReady && callback) {
				e = e || window.event;

				callFn.call(this, callback, e);
				callback = null;
			}
		}
	}

	function callFn(fn, e) {
		if (!document.body) {
			//console.log("callFn called");
			window.setTimeout(core.utils.delegate(this, callFn, fn, e), 50);
		} else {
			if (typeof fn === "function")
				fn(e);
			isDomReady = true;
		}
	}

	function testBodyReady() {
		if (bodyReadyTimer)
			window.clearTimeout(bodyReadyTimer);
		//console.log(document.readyState);
		if (document.readyState !== "loading" && !isDomReady && !isBodyReady) {
			if (document && document.body) {
				var elt;
				try {
					elt = document.createElement("span");
					document.body.appendChild(elt);
					document.body.removeChild(elt);
					isBodyReady = true;
					unbindDomLoaded(null);
					//console.log("Body IS READY!!!");
				} catch (e) { /*console.log("Body is not ready " + e.message);*/
				}
				elt = null;
			}

		}
		if (!isBodyReady)
			bodyReadyTimer = window.setTimeout(testBodyReady, 100);

	}

	function bindDomReady(fn) {
		if (isDomReady || isBodyReady || document.readyState === "complete")
			callFn.call(this, fn);

		else {
			callback = !!callback ? (function (f1, f2) {
				return function (e) {
					f1(e);
					f2(e);
				};
			})(callback, fn) : fn;

			if (!readyBound) {
				var d = window.document;

				if ("addEventListener" in d) {
					d.addEventListener("onreadystatechange", unbindDomLoaded, false);
					d.addEventListener("DOMContentLoaded", unbindDomLoaded, false);
					window.addEventListener("load", unbindDomLoaded, false);
				} else if ("attachEvent" in d) {
					d.attachEvent("onreadystatechange", unbindDomLoaded);
					d.attachEvent("DOMContentLoaded", unbindDomLoaded);
					window.attachEvent("onload", unbindDomLoaded);
				}
				readyBound = true;
			}

			testBodyReady();
		}
	}

	var livecache = [],
		liveinited = false,
		livechangebound = false,
		evttimer = {};

	function bindLives() {
		var newCache = [];
		while (livecache.length) {
			var live_i = livecache.shift(),
				elt = find(live_i.selector);

			if (!!elt.length) {
				core.utils.log("Bining lives for " + live_i.eventName + " on " + elt.length + " " + live_i.selector);
				this.bind(elt, live_i.eventName, live_i.fn);
			}

			newCache.push(live_i);
		}
		livecache = newCache;
		//console.log(livecache.length);

		if (!livechangebound && document.body) {
			livechangebound = true;
			this.bindonchange(document.body, core.utils.delegate(this, bindLives), "bindLives");
		}
	}

	function live(selector, eventName, fn) {
		if (typeof fn === "function") {
			livecache.push({"selector": selector, "eventName": eventName, "fn": fn});
			if (!liveinited) {
				liveinited = true;
				bindDomReady.call(this, core.utils.delegate(this, bindLives));
			}
		}
	}

	function callChangeCallback(fn, evtId, evt) {
		if (evt && evt.target) {
			///#IFDEF DEBUG
			core.utils.log("ChangeCallback " + evtId);
			///#ENDIF
			if (evttimer[evtId])
				window.clearTimeout(evttimer[evtId]);
			///#IFDEF DEBUG
			core.utils.log("callChangeCallback called " + evt.type);
			///#ENDIF
			evttimer[evtId] = window.setTimeout(function () {
				///#IFDEF DEBUG
				core.utils.log("callChangeCallback calling handler for " + evt.type + " " + evtId || "");
				///#ENDIF
				evttimer[evtId] = null;
				fn(evt);
			}, 100);
		}
	}

	function callMutationCallback(fn, observerId, mutations, observer) {
		///#IFDEF DEBUG
		core.utils.log("callMutationCallback " + observerId);
		///#ENDIF
		if (mutations) {
			///#IFDEF DEBUG
			core.utils.log("callMutationCallback[" + observerId + "] found mutations: " + mutations.length);
			///#ENDIF

			if (evttimer[observerId])
				window.clearTimeout(evttimer[observerId]);

			evttimer[observerId] = window.setTimeout(function () {
				window.clearTimeout(evttimer[observerId]);
				evttimer[observerId] = null;
				///#IFDEF DEBUG
				core.utils.log("callMutationCallback[" + observerId + "] calling callback: " + fn.toString());
				///#ENDIF
				fn(mutations);
			}, 100);
		}
	}

	function fallbackDomChangeHandler() {
		///#IFDEF DEBUG
		core.utils.log("fallbackDomChangeHandler called ");
		///#ENDIF
		if (domchangecache) {

			var newcache = [];
			///#IFDEF DEBUG
			core.utils.log("fallbackDomChangeHandler queue length is " + domchangecache.length);
			///#ENDIF
			for (var i = 0, l = domchangecache.length; i < l; i++) {
				if (domchangecache[i].elt.parentElement) {
					if (domchangecache[i].elt.outerHTML !== domchangecache[i].cache) {
						//console.log("fallbackDomChangeHandler called");
						///#IFDEF DEBUG
						core.utils.log("fallbackDomChangeHandler calling callback");
						///#ENDIF
						domchangecache[i].cache = domchangecache[i].elt.outerHTML;
						domchangecache[i].fn();
					}
					newcache.push(domchangecache[i]);
				} else {
					///#IFDEF DEBUG
					core.utils.log("fallbackDomChangeHandler calling callback (no parent elt)");
					///#ENDIF
					domchangecache[i].fn();
					domchangecache[i].elt = null;
					domchangecache[i] = null;
				}
			}
			domchangecache = newcache.length > 0 ? newcache : null;
		}
	}

	core.helpers.dom = {

		bindonchange: function (elt, fn) {
			var evtId = "domchange" + domchangeIndx++;

			if (MutationObserver) {
				///#IFDEF DEBUG
				core.utils.log("bindonchange mutations " + evtId + " for " + elt);
				///#ENDIF
				// define a new observer
				var observer = new MutationObserver(core.utils.delegate(this, callMutationCallback, fn, evtId));
				// have the observer observe foo for changes in children
				observer.observe(elt, {/*attributes: true, */childList: true, subtree: true});
			}
			else if ("addEventListener" in elt) {
				//console.log("bindonchange DOMNodeInserted: " + ("DOMNodeInserted" in elt));
				//console.log("bindonchange DOMNodeInsertedIntoDocument: " + ("DOMNodeInsertedIntoDocument" in elt));
				///#IFDEF DEBUG
				core.utils.log("bindonchange DOMNodeInserted/DOMNodeInsertedIntoDocument " + evtId + " for " + elt);
				///#ENDIF

				var cb = core.utils.delegate(this, callChangeCallback, fn, evtId);
				elt.addEventListener('DOMNodeInserted', cb, false);
				elt.addEventListener('DOMNodeRemoved', cb, false);
				elt.addEventListener('DOMNodeInsertedIntoDocument', cb, false);
				elt.addEventListener('DOMNodeRemovedFromDocument', cb, false);
			} else if (typeof document.onpropertychange !== "undefined") { // for IE 5.5+
				///#IFDEF DEBUG
				core.utils.log("bindonchange fallback " + evtId + " for " + elt);
				///#ENDIF
				if (!domchangecache) {
					domchangecache = [];
					window.setInterval(core.utils.delegate(this, fallbackDomChangeHandler, evtId), 300);
				}
				domchangecache.push({elt: elt, fn: fn, cache: elt.outerHTML});
				//document.attachEvent("onpropertychange", core.utils.delegate(this, callChangeCallback, fn));
			}
		},

		bind: function (elt, evtName, fn, forceLive) {
			if (typeof elt === "string") {
				var elts = find(elt);
				///#IFDEF DEBUG_OR_Testpages
				//if (forceLive)
				//	core.utils.log("Forcing Live for " + elt +" on " + evtName);
				///#ENDIF
				if (elts.length > 0 && !forceLive) {
					this.bind(elts, evtName, fn);
				} else {
					live.call(this, elt, evtName, fn);
				}
			} else if (elt.nodeType || elt === window || elt === window.document) {
				if (evtName.toLocaleLowerCase() === "ready" && elt === window.document)
					bindDomReady.call(this, fn);
				else {
					if (typeof elt[evtName] === "function") {
						var myfn = fn,
							their = elt[evtName];
						elt[evtName] = null;
						fn = function (evt) {
							myfn(evt);
							return their(evt);
						};
					}

					try {
						this.unbind(elt, evtName, fn);
					} catch (e) {
					}

					if ("addEventListener" in elt) {
						if (evtName.toLocaleLowerCase() === "onmousewheel" && "DOMMouseScroll" in elt)
							evtName = "onDOMMouseScroll";

						elt.addEventListener(evtName.slice(2).toLocaleLowerCase(), fn, false);
					} else if ("attachEvent" in elt) {
						elt.attachEvent(evtName, fn);
					}
				}
			} else if (elt instanceof Array || elt.length) {
				for (var i = 0, l = elt.length; i < l; i++)
					this.bind(elt[i], evtName, fn);
			}
		},

		unbind: function (elt, evtName, fn) {
			if ("removeEventListener" in elt) {
				if (evtName.toLocaleLowerCase() === "onmousewheel" && "DOMMouseScroll" in elt)
					evtName = "onDOMMouseScroll";
				elt.removeEventListener(evtName.slice(2).toLocaleLowerCase(), fn, false);
			} else if ("detachEvent" in elt) {
				elt.detachEvent(evtName, fn);
			}
		},

		append: function (newElt, whereTo) {
			if (!!newElt && !!whereTo) {
				whereTo.appendChild(newElt);
			}
		},

		remove: function (elt) {
			if (elt && elt.parentNode) {
				elt.parentNode.removeChild(elt);
			}
		}
	};
})(core || {});


})(core || {});

	

/// File include: 'core/http.js'

(function (core, XMLHttpRequest) {
	var transport = null,
		fallbackAjax = function () {
			this.initPromise = this._init();
		},
		dataTypes = {
			"JSON": "json",
			"Text": "text",
			"HTML": "html"
		},
		sendMethods = {
			"GET": "get",
			"POST": "post"
		},

		options = {
			url: "",
			ssid: "",
			async: true,
			timeout: 6000,
			method: sendMethods.POST,
			requestType: "application/json",
			responseType: dataTypes.JSON,
			charset: "utf-8",
			useCreds: !0,
			doubeencode: !0
		};

	fallbackAjax.prototype = {
		form: null,
		ifr: null,
		initPromise: null,
		_loadDone: false,
		_quirksInterval: null,
		status: 0,
		responseText: "",
		statusText: "",
		method: "POST",
		url: "",

		open: function (inputMethod, inputUrl) {
			if (inputMethod) {
				this.method = inputMethod.toUpperCase();
			}
			else {
				this.method = 'POST';
			}

			this.url = inputUrl || window.location.href;
		},

		onload: null,
		onerror: null,

		initContainer: function () {
			var interval;
			return core.helpers.Promise.race([
				core.helpers.Promise.timeout(options.timeout)
					.then(function () {
						throw new Error("Fallback request timeout");
					}),
				new core.helpers.Promise(function (resolve) {
					interval = window.setInterval(function () {
						if (fallbackAjax.container) {
							resolve(fallbackAjax.container);
						}
						else if (document.body) {
							resolve(document);
						}
					});
				})
			])
				.then(function (doc) {
					window.clearTimeout(interval);
					return doc;
				}, function (err) {
					window.clearTimeout(interval);
					throw err;
				});
		},

		_init: function () {
			return this.initContainer()
				.then(core.utils.delegate(this, function (doc) {
					var elt,
						ifrId = "kl_ajax_ifr" + (new Date()).getTime();
					try {
						elt = doc.createElement('<iframe name="' + ifrId + '">');
					} catch (e) {
						elt = doc.createElement("iframe");
						elt.name = ifrId;
					}
					elt.name = ifrId;

					doc.body.appendChild(elt);

					elt.id = ifrId;
					elt.frameBorder = 0;
					elt.border = 0;
					elt.style.position = "absolute";
					elt.style.left = "-10px";
					elt.style.top = "-10px";
					elt.style.width = "10px";
					elt.style.height = "10px";

					this.ifr = elt;

					this.form = doc.createElement("form");
					this.form.enctype = "application/x-www-form-urlencoded";
					this.form.target = ifrId;
					var input = doc.createElement("input");
					input.type = "hidden";
					input.name = "data";
					input.id = 'datafor' + ifrId;

					core.helpers.dom.append(input, this.form);
					core.helpers.dom.append(this.form, doc.body);
				}));
		},

		_handleLoaded: function () {
			if (!this._loadDone) {
				this._loadDone = true;
				this.status = 200;
				this.responseText = "";
				this.statusText = "Ok";

				if (typeof this.onload == "function") {
					this.onload();
				}

				return this.destroy();
			}
		},

		_handleError: function () {
			if (!this._loadDone) {
				this._loadDone = true;
				this.status = 500;
				this.responseText = "";
				this.statusText = "Error";

				if (typeof this.onerror == "function") {
					this.onerror();
				}

				return this.destroy();
			}
		},

		_quirkstest: function (done) {
			if (!this._loadDone) {
				if (this.ifr.document && this.ifr.document.readyState == "complete" && this.ifr.onload) {
					window.clearInterval(this._quirksInterval);
					done();
				}
			}
		},
		send: function (data) {
			return this.initPromise.then(core.utils.delegate(this, function () {
				var inputs = this.form.getElementsByTagName("input");
				if (inputs.length > 0) {
					this.loadHandler1 = core.utils.delegate(this, this._handleLoaded);
					this.errHandler1 = core.utils.delegate(this, this._handleError);

					var quirkstest = core.utils.delegate(this, this._quirkstest, this.loadHandler1, this.errHandler1);
					this._loadDone = false;
					return core.helpers.Promise.resolve()
						.then(core.utils.delegate(this, function () {
							inputs[0].value = data;
							core.helpers.dom.bind(this.ifr, "onload", this.loadHandler1);
							core.helpers.dom.bind(this.ifr, "onerror", this.errHandler1);
							this.ifr.onload = this.loadHandler1;
							this.ifr.onerror = this.errHandler1;

							this._quirksInterval = window.setInterval(quirkstest, 100);

							this.form.method = this.method;
							this.form.action = this.url;
							this.form.submit();
							this.form = null;

							inputs = null;
						}));
				}
				throw new Error("Data input not found on the form to send!");
			}));
		},

		destroy: function () {
			window.clearInterval(this._quirksInterval);
			return core.helpers.Promise.resolve()
				.then(function () {
					if (this.form) {
						if (this.ifr) {
							this.ifr.onload = null;
							this.ifr.onerror = null;
							this.ifr.parentNode.removeChild(this.ifr);
							try {
								core.helpers.dom.unbind(this.ifr, "onload", this.loadHandler1);
							} catch (e) {
							}
							try {
								core.helpers.dom.unbind(this.ifr, "onerror", this.errHandler1);
							} catch (e) {
							}
							this.ifr = null;
						}

						this.form.parentNode.removeChild(this.form);
						this.form = null;
					}
				});
		}
	};

	function jsonp(url, callbackName) {
		if (!url || typeof url !== 'string') {
			return core.helpers.Promise.reject(new Error("No URL provided or url is not a string. Received URL:" + url));
		}

		return new core.helpers.Promise(function (resolve, reject) {
			callbackName = callbackName || 'jsonp_callback';
			window.kfp = window.kfp || {};
			window.kfp[callbackName] = function (data) {
				resolve(data);
			};
			var head = document.getElementsByTagName("head")[0] || document.body;
			var script = document.createElement("script");
			script.type = 'text/javascript';
			script.src = url;

			initRequestPromise(script)
				.fail(reject)
				.then(function () {
					head.removeChild(script);
				});
			head.appendChild(script);
		});
	}

	function getXmlHttp() {
		var xhrCache = window.XMLHttpRequest,
			xhr = XMLHttpRequest;

		try { // Chrome throws an exception when the XMLHttpRequest is called as a function
			if (!(xhr() instanceof xhr)) {
				try {
					delete window.XMLHttpRequest;
				} catch (e) {
					window.XMLHttpRequest = xhr = null;
				}

				if (window.XMLHttpRequest) { // Chrome
					XMLHttpRequest = xhr = window.XMLHttpRequest;
				} else {
					XMLHttpRequest = xhr = (core.utils.restorer && core.utils.restorer.getNative("XMLHttpRequest")).XMLHttpRequest || xhrCache;
				}
				window.XMLHttpRequest = xhrCache;
			}
		} catch (e) {
		}

		return xhr;
	}

	function getTransport(isCrossDomain, noFallback) {
		if (!transport) {
			if (isCrossDomain && window.XDomainRequest) {
				transport = fallbackAjax;
				//querySelector check has been added here to define whether the browser used is an IE7 exactly.
				//The reason behind this is that IE7 supports XMLHttpRequest, however, it doesn't allow crossdomain requests.
				//So in this case we have to use fallback to send tracks and other data to our servers.
			} else if (window.XMLHttpRequest && document.querySelector) {
				transport = getXmlHttp();
			}

			if (!transport && typeof window.ActiveXObject != 'undefined' && !isCrossDomain) {
				try {
					if (new ActiveXObject("Msxml2.XMLHTTP"))
						transport = function () {
							return new ActiveXObject("Msxml2.XMLHTTP");
						}
				} catch (e) {
					try {
						if (new ActiveXObject("Microsoft.XMLHTTP"))
							transport = function () {
								return new ActiveXObject("Microsoft.XMLHTTP");
							}
					} catch (e1) {
						core.utils.log("http.getTransport: could not create XHR: " + e1.message, core.utils.log.ERROR);
					}
				}
			}

			if (!transport) {
				transport = fallbackAjax;
				core.utils.log("Falling back transport ");
			}
		}
		if (noFallback && transport == fallbackAjax)
			transport = null;

		return transport ? new transport() : null;
	}

	function init(opts) {
		if (opts) {
			for (var paramName in opts) {
				if (opts.hasOwnProperty(paramName))
					options[paramName] = opts[paramName];
			}
		}
		return this; //for chaining
	}

	function initRequestPromise(xhr) {
		return new core.helpers.Promise(function (resolve, reject) {
			if ("onreadystatechange" in xhr) {
				xhr.onreadystatechange = function () {
					if (xhr.readyState == 4) {
						if (xhr.status == 200) {
							return resolve(xhr);
						}
						reject(xhr);
					}
				};
			}

			if ("onload" in xhr) {
				xhr.onload = function () {
					return resolve(xhr);
				};
			}

			if ("onerror" in xhr) {
				xhr.onerror = function () {
					return reject(xhr);
				};
			}
			if ("ontimeout" in xhr) {
				xhr.ontimeout = function () {
					return reject(xhr);
				};
			}
		});
	}

	function loadData(opts) {
		return core.helpers.Promise.resolve()
			.then(function () {
				opts = opts || {};
				var url = opts.url || options.url || "",
					isCrossDomain = testCrossDomain.call(this, url),
					xhr = getTransport(isCrossDomain, !!opts.noFallback);

				if (!xhr) {
					throw new Error("Can't get transport for making a request");
				}

				var data = opts.data,
					async = ("async" in opts ? opts : options).async,
					method = opts.method || options.method,
					useCreds = !!((opts.useCreds === true || opts.useCreds === false) ? opts.useCreds : options.useCreds),
					timeout = opts.timeout || options.timeout,
					requestEnc = "charset" in opts ? opts.charset : options.charset,
					requestType = (opts.requestType || options.requestType) + ( requestEnc ? "; charset=" + requestEnc : "" ),
					requestPromise;

				if ('overrideMimeType' in xhr) {
					xhr.overrideMimeType(requestType);
				}

				if (method.toLowerCase() == sendMethods.GET) {
					url = url + ( (url.indexOf("?") === -1) ? "?" : "&" ) + data;
					data = null;
				}
				requestPromise = initRequestPromise(xhr).then(successHandler, errHandler);
				xhr.open(method, url, async);

				if ("timeout" in xhr && !!async) {
					xhr.timeout = timeout;
				}

				if ("setRequestHeader" in xhr) {
					xhr.setRequestHeader("Content-Type", requestType);
				}

				if (useCreds) {
					try {
						xhr.withCredentials = true;
					} catch (e) {
						core.utils.log("No withCredentials");
					}
				}

				try {
					if (isCrossDomain) {
						xhr.crossDomain = true;
					}
				} catch (e) {
					core.utils.log("crossDomain can not be set");
				}
				///#IFDEF DEBUG_OR_Testpages
				core.utils.log("Sending to " + url.slice(0, 20));
				///#ENDIF
				xhr.send(data || "");
				return requestPromise;
			});
	}

	function testCrossDomain(url) {
		var anch = document.createElement("a"),
			anchExt = document.createElement("a");

		anch.href = ("" + window.location.href).toLowerCase();
		anchExt.href = url;

		return ((anchExt.protocol != anch.protocol) || (anchExt.host != anch.host));
	}


	function successHandler(xhr) {
		var result = xhr.responseText || "";
		//If JSON, try to parse it
		if (options.responseType == dataTypes.JSON) {
			return core.helpers.Promise.resolve()
				.then(function () {
					return core.utils.JSON.decode(result);
				})
				.fail(function () {
					return errHandler({
						responseText: result,
						status: 500,
						statusText: "Response type stated as JSON, but JSON parsing has failed"
					});
				});
		}
		return result;
	}

	function errHandler(xhr) {
		throw new Error("Request error! Response:" + xhr.responseText + " Status:" + xhr.status + " Error:" + xhr.statusText);
	}


	core.http = {
		setAsync: function (val) {
			options.async = !!val;
			return this;
		},
		init: init,
		send: loadData,
		jsonp: jsonp
	};

})(core || {}, window.XMLHttpRequest);
	

/// File include: 'core/app.js'

(function (core) {

	var trackRes = '/track',

		handlers = {},
		handlersPromises = [],
		handlerstypes = [],
		currentDataHash,
		prevDataHash,

		sendTimer = null,
		serverUrl = 'https://ru.fp.kaspersky-labs.com:443',
		trackUrl = serverUrl + trackRes,
		globals = {
			"utils": true,
			"helpers": true,
			"http": true
		};


	/**
	 * Checks whether the data passed is the same as in the previous track (excluding timestamps)
	 * @param data {Object} Data prepared to send in the current track
	 * @returns {Boolean} True if data passed is the same compared to the previous track, false otherwise
	 */
	function checkSameDataSent(data) {
		currentDataHash = core.utils.hash(core.utils.JSON.encode(getHashWithoutTime(data)));
		return currentDataHash === prevDataHash;
	}

	/**
	 * Makes a deep copy of the object provided, excluding all properties named "time"
	 * @param obj {Object} Object to clone
	 * @returns {Object} Copied object with excluded "time" properties
	 */
	function getHashWithoutTime(obj) {
		var copy, i, attr, len;
		// Handle the 3 simple types, and null or undefined
		if (null === obj || "object" !== typeof obj) {
			return obj;
		}
		// Handle Date
		if (obj instanceof Date) {
			copy = new Date();
			copy.setTime(obj.getTime());
			return copy;
		}
		// Handle Array
		if (obj instanceof Array) {
			copy = [];
			len = obj.length;
			for (i = 0; i < len; i++) {
				copy[i] = getHashWithoutTime(obj[i]);
			}
			return copy;
		}
		// Handle Object
		if (obj instanceof Object) {
			copy = {};
			//historyLength is a workaround for IE 8- bug which randomly changes window.history.length property
			//when page contains a form with an input
			//See https://support.microsoft.com/en-us/kb/979926 for the additional info
			for (attr in obj) {
				if (obj.hasOwnProperty(attr) && attr !== 'time' && attr !== 'historyLength') {
					copy[attr] = getHashWithoutTime(obj[attr]);
				}
			}
			return copy;
		}
	}

	/**
	 * Creates a timeout timer to send a new track. If the timer exists at the moment of execution, stops it and creates a new one.
	 * @param options {Object} Options to pass to {@link sendData}.
	 */
	function sendByTimer(options) {
		if (sendTimer) {
			window.clearTimeout(sendTimer);
		}
		sendTimer = window.setTimeout(core.utils.delegate(this, sendData, options), core.utils.session.getSync().period);
	}

	/**
	 * Gathers data from all the handlers and sends in in the track.
	 * @param [options] {Object} Various sending options
	 * @param options.sendSync {Boolean} If true, track will be sent in a blocking pattern, otherwise it'll be sent in a non-blocking pattern
	 * @returns {Promise} Promise resolves with response from the server where we've sent our track, or rejects with an error happened.
	 */
	function sendData(options) {
		if (sendTimer) {
			window.clearTimeout(sendTimer);
		}
		sendTimer = null;

		var sendSync = !!(options && options.sendSync);
		//Use fail-safe mode here, so that any rejected promise (such as failed handler wouldn't cancel track being sent)
		return collectData(options && options.force)
			.then(function (data) {
				//If we're going to send the same data as in the previous request, abort the request
				if (checkSameDataSent(data)) {
					throw new Error("Same data detected");
				}
				return data;
			})
			.then(function (data) {
				return core.http.send({
					data: core.utils.JSON.encode(data),
					async: !sendSync
				});
			})
			.then(function () {
				prevDataHash = currentDataHash;
			}, function () {
			})
			.then(function () {
				//Plan the next iteration request as usual (by timer)
				sendByTimer.call({"sendSync": false});
			});
	}


	function collectData(force) {
		var dateObj = new Date(),
			data = {
				time: [
					(dateObj.getTime()),		//timestamp
					dateObj.getTimezoneOffset() || 0	//offset
				],
				url: core.helpers.strHelper.maskNumbers(window.location.href),
				ref: core.helpers.strHelper.maskNumbers(document.referrer || "")
			},
			i, l, promiseArray = [];

		l = handlerstypes.length;
		for (i = 0; i < l; i++) {
			promiseArray.push((function (handlerName) {
				var handler = handlers[handlerName];
				if (handler && handler.hasOwnProperty('getData') && typeof handler.getData === "function") {
					return core.helpers.Promise.resolve()
						.then(function () {
							return handler.getData(force);
						})
						.then(function (dataItem) {
							if (dataItem !== null && dataItem !== undefined) {
								return data[handlerName] = dataItem;
							}
						});
				}
				return null;
			})(handlerstypes[i]));
		}
		//Use fail-safe mode here, so that any rejected promise (such as failed handler wouldn't cancel track being sent)
		return core.helpers.Promise.all(promiseArray, true)
			.then(function () {
				return data;
			});
	}

	/**
	 * Initializes all the handlers by calling their "start" method (if the handler provides it).
	 * Registers handlers list to use it afterwards.
	 * Calls {@link sendData} as soon as each handler has been activated.
	 */
	function initHandlers() {
		//Use fail-safe mode here to prevent all handlers from being stopped if any of them fails
		return core.helpers.Promise.all(handlersPromises, true);
	}

	/**
	 * Stops all handlers having an "abort" method with a reason provided.
	 * @param reason {String} Reason to stop the handlers.
	 */
	function rejectHandlers(reason) {
		var i, l, handlerId;
		l = handlerstypes.length;
		for (i = 0; i < l; i++) {
			handlerId = handlerstypes[i];
			if (handlers[handlerId] && handlers[handlerId].hasOwnProperty('abort') && typeof handlers[handlerId].abort === "function") {
				try {
					handlers[handlerId].abort({
						"abortReason": reason
					});
				} catch (ignore) {
				}
			}
		}
	}

	/**
	 * Opens up global methods on "window" to allow MDS script integration
	 */
	function createExternalHooks() {
		window.kfp = window.kfp || {};
		//Getting session ID syncronously. Extremely easy to implement, but highly prone to receiving null instead of session ID.
		// The risk is higher when called early after the script loads.
		window.kfp.get_oxxfgh = function () {
			return core.utils.session.getSync().id;
		};
		//Same as above, but returns Promise instead of session ID directly. This solved the issue with empty session IDs being returned.
		window.kfp.get_oxxfgh_async = function () {
			return core.utils.session.get().then(function (session) {
				return session.id;
			});
		};

		window.kfp.generate_uuid = function () {
			return core.utils.uuid.generate();
		};
		window.kfp.cookies = core.helpers.cookies;
	}


	/**
	 * Registers a new handler into DAS.
	 * @param name {String} Handler name, must be unique among all handlers.
	 * @param requires {Array} A list of the required dependencies. Each of them will be provided as a separate argument to the handler creator function.
	 * @param fnCreator {Function} A handler creator function
	 */
	kl.registerHandler = function (name, requires, fnCreator) { // jshint ignore:line
		var promise = new core.helpers.Promise(function (resolve, reject) {
			if (typeof fnCreator === "function") {
				var args = [];
				requires = requires || [];
				for (var i = 0, l = requires.length; i < l; i++) {
					var argName = requires[i].toLowerCase();
					if (globals[argName]) {
						args.push(core[argName] || null);
					}
				}

				return resolve(fnCreator.apply(null, args));
			}
			reject(new Error("Handler requires a creator function as 3rd argument"));
		})
			.then(function (handler) {
				if (handler.hasOwnProperty("start") && typeof handler.start === "function") {
					return core.helpers.Promise.resolve()
						.then(function () {
							return handler.start({
								"sendTrigger": function (options) {
									if (!options) {
										options = {};
									}
									options.force = true;
									return sendData(options);
								},
								"getServerUrl": function () {
									return serverUrl;
								}
							});
						})
						.then(function () {
							return handler;
						});
				}
				return handler;
			})
			.then(function (handler) {
				if (!handlers[name]) {
					handlerstypes.push(name);
					handlers[name] = handler;
				}
			})
			.fail(function (err) {
				var i, length = handlerstypes.length;
				for (i = 0; i < length; i++) {
					if (handlerstypes[i] === name) {
						handlerstypes.splice(i, 1);
						break;
					}
				}
				delete handlers[name];
				throw err;
			});

		handlersPromises.push(promise);
		return promise;
	};

	/**
	 * Initializes DAS. Handles all the preparations to run DAS as intended.
	 */
	kl.init = function () { // jshint ignore:line
		core.http.init({
			url: trackUrl,
			responseType: "text",
			async: true
		});
		createExternalHooks();
		return core.utils.session.init()
			.then(initHandlers, function () {
				core.utils.log("Failed to receive Session ID. Startup aborted!");
			})
			.then(sendData)
	};

	///#IFDEF TEST
	kl._api = {
		sendData: sendData,
		collectData: collectData,
		initHandlers: initHandlers,
		rejectHandlers: rejectHandlers,
		createMdsIntegration: createExternalHooks,
		handlers: handlers,
		handlerstypes: handlerstypes
	};
	///#ENDIF

})(core || {}); // jshint ignore:line

	
	
})(kl || {});

	

/// File include: 'handlers/_.js'

/// <reference path="behaviorhandler.js" />



/// File include: 'handlers/version.js'

kl.registerHandler("cha", [], function () {
	return {
		getData: function() {
            return "s-31-58-g7db7270";
		}
	};
});



/// File include: 'handlers/browsersessionhandler.js'

kl.registerHandler("geugae", ["utils"], function (utils) {
	return {
		getData: function() {
            return utils.session.get().then(function (session) {
	            return session.id;
            });
		}
	};
});



/// File include: 'handlers/browserhandler.js'

; kl.registerHandler("browser", ["utils", "helpers"], function (utils, helpers) {
	var datachanged = false,
        navProps = ["appCodeName", "appMinorVersion", "appName", "appVersion", "browserLanguage", "buildID", "cookieEnabled", "cpuClass", "doNotTrack", "hardwareConcurrency", "language", "maxTouchPoints", "msManipulationViewsEnabled", "msMaxTouchPoints", "msPointerEnabled", "onLine", "oscpu", "platform", "pluginFilenames", "pointerEnabled", "product", "productSub", "systemLanguage", "userAgent", "userLanguage", "vendor", "vendorSub", "webdriver"],
		ccfn = new Function("/*@cc_on\
			return { \
                enabled: true, \
                jscript_version: @_jscript_version, \
                win32: @_win32 };\
		@*/"),
		options = { sendTrigger: function () { } };

	function startHandler(o) {
		options = helpers.objectHelper.extend(options, o);
		gather();
	}

    function copyProperties(target, source, field_names) {
        for (var i=0, l=field_names.length; i<l; i++) {
            if (source[field_names[i]])
                target[field_names[i]] = source[field_names[i]];
        }
        return target;
    }
    
    function cloneArray(source, converter) {
        var target = [];
        if (source.length) {
            for (var i = 0, len = source.length; i < len; i++) {
                if (source[i]) {
                    target.push(converter(source[i]));
                }
            }
        }
        return target;
    }

    function copyPlugin(source) {
        var plugin = {};
        copyProperties(plugin, source, ["description", "filename", "name", "version"]);
        plugin.mime_type = cloneArray(source, function(s) {
            return copyProperties({}, s, ["type", "suffixes", "description"]);
        });
        return plugin;
    }

    function getNavigator() {
        var navi = window.navigator || window.clientInformation,
	        data = {
	            "hasMsManipulationViewsEnabled": "msManipulationViewsEnabled" in navi,
	            "hasMsPointerEnabled": "msPointerEnabled" in navi
	        },
        	plugins = navi.plugins;

        try{ data.langs = navi.languages && ([]).concat(navi.languages); }catch(e){}

        for(var ni=0, nl=navProps.length; ni<nl; ni++)
        	try{ data[navProps[ni]]=navi[navProps[ni]]; }catch(e){}

        if (plugins) {
            try {
                data.plugins = cloneArray(plugins, copyPlugin);
            } catch (eep) { }
        }
        if (data.hasMsManipulationViewsEnabled || data.hasMsPointerEnabled) {
            try {
                data.hasMediaDevices = typeof (navi.mediaDevices) != "undefined";
            } catch (ee0) { }
            try {
                data.isPluginsInstanceOfPluginArray = window["PluginArray"]&&navi.plugins instanceof window["PluginArray"];
            } catch (ee1) { }
            try {
                data.isPluginsInstanceOfMSPluginsCollection = window["MSPluginsCollection"]&&navi.plugins instanceof window["MSPluginsCollection"];
            } catch (ee2) { }
        }
        //helpers.objectHelper.copyProperties(data.navigator, );

        return data;
    }

    function getWindow() {
        return { 
            hasActiveXObject: "ActiveXObject" in window
        };
    }

    function getConditionalCompilation() {
       return (ccfn)() || { enabled: false };
    }

    function getHtmlCC() {
        var elt, html = "", txt = [], spans,
			conds = ["lte IE 6", "IE 6", "IE 7", "IE 8", "IE 9", "IE 10", "IE 11", "gt IE 11", "IEMobile"];
        try {
			elt = document.createElement("div");
			elt.kljs_elt = true;

			for (var ci = conds.length; ci--;) {
				html += "<!--[if " + conds[ci] + "]><span>" + conds[ci] + "</span><![endif]-->";
			}
			elt.innerHTML = html;
			spans = elt.getElementsByTagName("span");
			for (var si = spans.length; si--;) {
				txt.push((spans[si] || spans.item(si)).innerHTML);
			}
			
			spans = null;
			elt.innerHTML = "";
			elt = null;

            if (txt.length > 0) {
                return {
                    enabled: true,
                    tests: txt
                };
            }
		} catch (e) { utils.log("ERROR " + e.message); }
        return { enabled: false };
    }


	function gather() {
		var data = {
			time: (new Date()).getTime(),
			url: helpers.strHelper.maskNumbers(window.location.href),
			name: utils.utf8.encode(helpers.strHelper.maskNumbers(window.name)),
			domain: utils.utf8.encode(document.domain),
			charset: document.characterSet || document.charset || "",
			defenc: document.defaultCharset,
			historyLength: window.history.length,
			java: navigator.javaEnabled(),
            navigator: getNavigator(),
            window: getWindow(),
			jsCC: getConditionalCompilation(),
			htmlCC: getHtmlCC(),
			colors: [ document.bgColor, document.fgColor, document.linkColor, document.alinkColor, document.vlinkColor ]
		};

		try {
			var svg;
			if (!!document.createElementNS && !!(svg = document.createElementNS('http://www.w3.org/2000/svg', "svg")).createSVGRect) {
				//svg.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"></svg>';
				//svg = svg.firstChild;
				
				//if (svg && svg.nodeName && svg.nodeName.toLocaleLowerCase() == "svg" && svg.pixelUnitToMillimeterX) {
					data.svgppmx = svg.pixelUnitToMillimeterX;
					data.svgppmy = svg.pixelUnitToMillimeterY;
					data.svgscrppmx = svg.screenPixelToMillimeterX;
					data.svgscrppmy = svg.screenPixelToMillimeterY;
				//}
			}/* else {
				svg = document.createElement('div');
				svg.innerHTML = '<v:shape adj="1" style="behavor: url(#default#VML);" xmlns:v="urn:schemas-microsoft-com:vml"/>';
				debugger;
			}*/
			svg = null;
		} catch (ee) { }

		datachanged = true;
		return data;
	}

	return {
		start: startHandler,
		getData: function getData() {
			return gather();
		}
	};
});



/// File include: 'handlers/mds.js'

kl.registerHandler("mds", ["utils"], function (utils) {
    function gatherData()
    {
        utils.storage.init("klaf_ie_user_storage");
        return { "did": utils.storage.getData("uid") };
    }

	return {
		getData: function() {
            return gatherData.call(this);
		}
	};
});



/// File include: 'handlers/loginhandler.js'

;kl.registerHandler("login", ["utils", "helpers"], function (utils, helpers) {
	var _userName = null,
		_userId = null,
		_obsSessionId = null,
		_loginReslt = null,
		_clientId = null,
		_sendTrigger = null,
		_readyToSend = false,
		initPromiseResolve, initPromiseReject,
		initPromise = new helpers.Promise(function (resolve, reject) {
			initPromiseResolve = resolve;
			initPromiseReject = reject;
		});
	
	function waitForInitialize() {
		return helpers.Promise.race([
			helpers.Promise.timeout(1000)
				.then(function () {
					throw new Error("Request timeout");
				}),
			initPromise
		]);
	}

	window.kfp = window.kfp || {};

	window.kfp.login_start = function login_start(clientId, phase) {
		_clientId = clientId;
		return waitForInitialize()
			.then(function () {
				return utils.session.get().then(function (session) {
					return session.id + "_" + session.loginCount;
				})
			})
			.then(function (sessionId) {
				_obsSessionId = sessionId;
				if (phase == 'login') {
					utils.session.increaseLoginCount();
					_readyToSend = true;
					return _sendTrigger({'sendSync': false}).then(function () {
						return sessionId;
					});
				} else if (phase == 'prelogin') {
					return sessionId;
				}
				throw new Error('unknown login phase');
			});
	};

	window.kfp.login = function login(clientId, obsSesionId, userId, userName, loginResult) {
		_userId = userId;
		_userName = userName;
		_clientId = clientId;
		_loginReslt = loginResult;
		_obsSessionId = obsSesionId;
		return waitForInitialize()
			.then(function () {
				_readyToSend = true;
				return _sendTrigger({'sendSync': false});
			});
	};

	function startHandler(o) {
		_sendTrigger = o.sendTrigger;
		return initPromiseResolve();
	}

	function abortHandler(o) {
		return initPromiseReject(o.abortReason);
	}

	return {
		start: startHandler,
		abort: abortHandler,
		getData: function getData() {
			var readyToSend = _readyToSend;
			_readyToSend = false;

			return readyToSend ? {
				"userId": _userId,
				"userName": _userName,
				"obsSessionId": _obsSessionId,
				"clientId": _clientId,
				"loginResult": _loginReslt
			} : null;
		}
	};
});



/// File include: 'handlers/mousehandler.js'

;kl.registerHandler("mouse", ["helpers"], function () {
	var obj = {
			click: {
				data: [],
				threshold: 100,
				overflow: false,
				types: {
					mousedown: 'down',
					mouseup: 'up',
					click: 'click'
				}
			},
			move: {
				prevEvent: {
					x: 0,
					y: 0
				},
				rawData: [],
				data: [],
				threshold: 1000,
				overflow: false
			},

			enterleave: {
				data: [],
				threshold: 100,
				overflow: false,
				types: {
					mouseover: 'enter',
					mouseout: 'leave'
				}
			},
		},
		useHiResTimestamps = false,
		eventOffset = null,
		nowOffset = null,
		flushData = false,
		charSet = " !#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[]^_`abcdefghijklmnopqrstuvwxyz{|}~",
		charSetLength = charSet.length,
		charSetModLength = Math.floor(charSetLength / 2);

	function calculateOffsets(event) {
		eventOffset = new Date().getTime() - event.timeStamp;
		if (useHiResTimestamps) {
			nowOffset = new Date().getTime() - window.performance.now();
		}
	}

	function getCurrentTime() {
		if (useHiResTimestamps) {
			return Math.round(window.performance.now() + nowOffset);
		}
		return new Date().getTime();
	}

	function getTimeStamp(event) {
		if (event.timeStamp) {
			return Math.round(event.timeStamp + eventOffset);
		}
		return getCurrentTime();
	}

	function getClickKey(event) {
		var button = event.button,
			prevEvent;

		if (!event.which && button !== undefined) {
			if (button & 1) {
				return 1;
			}

			if (button & 2) {
				return 3;
			}

			if (button & 4) {
				return 2;
			}
			//Should not happen. If it does, however, that means we're into a IE8- bug
			//where click events do not always contain a button ID
			//To pass it, we'll try to get the button ID from the previous event (it must be a 'mouseup' event)
			if (button === 0 && event.type === 'click' && obj.click.data.length) {
				prevEvent = obj.click.data[obj.click.data.length - 1];
				if (prevEvent.type === 'up') {
					return prevEvent.id;
				}
			}

			return 0;
		}

		return event.which;
	}

	function addEvent(name, listener) {
		if (typeof document.addEventListener === 'function') {
			return document.addEventListener(name, listener);
		}
		else if (document.attachEvent) {
			return document.attachEvent('on' + name, listener);
		}
		return false;

	}

	function removeEvent(name, listener) {
		if (typeof document.removeEventListener === 'function') {
			return document.removeEventListener(name, listener);
		}
		else if (typeof document.detachEvent === 'function') {
			return document.detachEvent('on' + name, listener);
		}
		return false;
	}

	function commonEventHandler(event) {
		if (eventOffset === null) {
			calculateOffsets(event);
		}

		switch (event.type) {
			case 'mousedown':
			case 'mouseup':
			case 'click':
			{
				return clickEvent(event);
			}
			case 'mousemove':
			{
				return moveEvent(event);
			}
			case 'mouseover':
			case 'mouseout':
			{
				return enterLeaveEvent(event);
			}
		}
	}

	function clickEvent(event) {
		if (flushData) {
			flush();
		}

		if (obj.click.data.length >= obj.click.threshold) {
			obj.click.overflow = true;
			return;
		}
		obj.click.data.push({
			type: obj.click.types[event.type],
			x: Math.round(event.clientX),
			y: Math.round(event.clientY),
			tgen: getTimeStamp(event),
			tin: getCurrentTime(),
			id: getClickKey(event)
		});
	}

	function enterLeaveEvent(event) {
		//No event.relatedTarget means we're leaving/entering the window itself, not any inner element
		if(!event.relatedTarget) {
			//IE 8- issue, the relatedTarget property is named differently depending to event type
			if (event.relatedTarget === undefined) {
				if (event.type == 'mouseover') event.relatedTarget = event.fromElement;
				if (event.type == 'mouseout') event.relatedTarget = event.toElement;
			}

			if(event.relatedTarget !== null) {
				return;
			}
			if (flushData) {
				flush();
			}

			if (obj.enterleave.data.length >= obj.enterleave.threshold) {
				obj.enterleave.overflow = true;
				return;
			}
			obj.enterleave.data.push({
				type: obj.enterleave.types[event.type],
				x: Math.round(event.clientX),
				y: Math.round(event.clientY),
				tgen: getTimeStamp(event),
				tin: getCurrentTime()
			});
		}
	}

	function moveEvent(event) {
		//Fixing Chrome Windows issue when mousemove has been constantly fired even if the mouse is idling
		//There's no well-known reason for it to perform so, probably some other programs use mouse event to prevent the PC from sleeping
		if (event.clientX === obj.move.prevEvent.x && event.clientY === obj.move.prevEvent.y) {
			return;
		}

		if (flushData) {
			flush();
		}

		obj.move.prevEvent.x = event.clientX;
		obj.move.prevEvent.y = event.clientY;
		if (obj.move.rawData.length >= obj.move.threshold) {
			obj.move.overflow = true;
			return;
		}

		obj.move.rawData.push({
			x: event.clientX,
			y: event.clientY,
			t: getTimeStamp(event)
		})
	}

	function makeMoveOutput() {
		var i, length, event, prevEvent, diff, delta = {
			x: '',
			y: '',
			t: ''
		}, deltaConcat;
		length = obj.move.rawData.length;
		for (i = 0; i < length; i++) {
			event = obj.move.rawData[i];

			//round the values even if it looks unnecessary. This is required for a possible IE + Selenium bug
			//where coordinates are returned as float instead of integer.
			event.x = Math.round(event.x);
			event.y = Math.round(event.y);
			//don't round the time as it's 100% rounded before that

			if (prevEvent) {
				diff = {
					x: event.x - prevEvent.x + charSetModLength,
					y: event.y - prevEvent.y + charSetModLength,
					t: event.t - prevEvent.t
				};
			}

			if (!prevEvent || !charSet.charAt(diff.x) || !charSet.charAt(diff.y) || !charSet.charAt(diff.t)) {
				//create new block
				obj.move.data.push(event);
				//if previous block exist, we should create the d (is for 'delta') field, concatenating data from delta object
				if (obj.move.data.length > 1) {
					if (deltaConcat = delta.x + delta.y + delta.t) {
						obj.move.data[obj.move.data.length - 2].d = deltaConcat;
					}
				}
				delta = {
					x: '',
					y: '',
					t: ''
				}
			}
			//update the deltas
			else if (diff.x || diff.y) {
				delta.x += charSet.charAt(diff.x);
				delta.y += charSet.charAt(diff.y);
				delta.t += charSet.charAt(diff.t);
			}
			prevEvent = event;
		}
		//if the data has ended, and we have something left in the delta object, put in into the latest block
		if (deltaConcat = delta.x + delta.y + delta.t) {
			obj.move.data[obj.move.data.length - 1].d = deltaConcat;
		}

		//flush the raw data before returning, we don't need it anymore
		obj.move.rawData = [];
		return obj.move.data;
	}

	function start() {
		//Start the listeners up!
		addEvent('mouseup', commonEventHandler);
		addEvent('mousedown', commonEventHandler);
		addEvent('click', commonEventHandler);
		addEvent('mousemove', commonEventHandler);

		//"Mouseover" and "mouseout" are being used here instead of "mouseenter" and "mouseleave" respectively on purpose.
		//This has been caused by inability to use the latter listeners on document/window/body in any browser except Chrome
		//(events are not triggered when mouse enters/leaves the browser).
		//The former listeners work everywhere so we've got no other choice but to emulate enter/leave features with this events.
		addEvent('mouseover', commonEventHandler);
		addEvent('mouseout', commonEventHandler);

		useHiResTimestamps = !!(window.performance && window.performance.now && window.performance.now instanceof Function);
	}

	function stop() {
		removeEvent('mouseup', commonEventHandler);
		removeEvent('mousedown', commonEventHandler);
		removeEvent('click', commonEventHandler);
		removeEvent('mousemove', commonEventHandler);
	}

	function flush() {
		obj.click.data = [];
		obj.click.overflow = false;
		obj.move.data = [];
		obj.move.rawData = [];
		obj.move.overflow = false;
		obj.enterleave.data = [];
		obj.enterleave.overflow = false;
		flushData = false;
	}

	return {
		start: start,
		abort: stop,
		getData: function (force) {
			var retObj;
			if (force && flushData) {
				flush();
			}

			retObj = {
				click: {
					data: obj.click.data
				},
				move: {
					data: makeMoveOutput()
				},

				enterleave: {
					data: obj.enterleave.data
				},
			};

			if (obj.click.overflow) {
				retObj.click.overflow = true;
			}
			if (obj.move.overflow) {
				retObj.move.overflow = true;
			}

			flushData = !!(obj.click.data.length + obj.move.data.length);
			return retObj;
		}
	};
});



/// File include: 'handlers/clientcapshandler.js'

;kl.registerHandler("clientcaps", [], function () {
	var data,
		start = function () {
			var body, clientCaps, el, clids, version, i, length;

			body = document.getElementsByTagName("body")[0];
			clientCaps = document.createElement("div");
			clientCaps.innerHTML = '<div style="behavior:url(#default#clientCaps)" ID="oClientCaps" ></div>';
			body.appendChild(clientCaps);

			el = document.getElementById("oClientCaps");

			if (typeof el.addBehavior === 'undefined') {
				return;
			}

			data = {
				availHeight: el.availHeight,
				availWidth: el.availWidth,
				bufferDepth: el.bufferDepth,
				colorDepth: el.colorDepth,
				connectionType: el.connectionType,
				cookieEnabled: el.cookieEnabled,
				cpuClass: el.cpuClass,
				height: el.height,
				javaEnabled: el.javaEnabled,
				platform: el.platform,
				systemLanguage: el.systemLanguage,
				userLanguage: el.userLanguage,
				width: el.width,
				capabilities: []
			};

			if (typeof el.getComponentVersion === 'undefined') {
				return;
			}

			//Features list as follows
			//@see {@link https://msdn.microsoft.com/en-us/library/ms531342(v=vs.85).aspx}
			//@see {@link http://ftp.urc.ac.ru/pub/OS/Windows/www/IE/6sp1/en/filelist.dat} for futher information on each list item.

			clids = ["{7790769C-0471-11D2-AF11-00C04FA35D02}", //Address book
				"{89820200-ECBD-11CF-8B85-00AA005B4340}", //Windows Desktop Update NT
				"{283807B5-2C60-11D0-A31D-00AA00B92C03}", //DirectAnimation
				"{4F216970-C90C-11D1-B5C7-0000F8051515}", //DirectAnimation Java Classes
				"{44BBA848-CC51-11CF-AAFA-00AA00B6015C}", //DirectShow
				"{9381D8F2-0288-11D0-9501-00AA00B911A5}", //Dynamic HTML Data Binding
				"{36F8EC70-C29A-11D1-B5C7-0000F8051515}", //TridataJava
				"{5A8D6EE0-3E18-11D0-821E-444553540000}", //Internet Connection Wizard
				"{89820200-ECBD-11CF-8B85-00AA005B4383}", //Internet Explorer Browser
				"{08B0E5C0-4FCB-11CF-AAA5-00401C608555}", //Windows Internet Explorer Classes for Java
				"{45EA75A0-A269-11D1-B5BF-0000F8051515}", //Internet Explorer Help
				"{DE5AED00-A4BF-11D1-9948-00C04F98BBC9}", //Internet Explorer Help Engine [HTMLHelp]
				"{22D6F312-B0F6-11D0-94AB-0080C74C7E95}", //Windows Media Player 6
				"{44BBA842-CC51-11CF-AAFA-00AA00B6015B}", //NetMeeting NT
				"{3AF36230-A269-11D1-B5BF-0000F8051515}", //Offline Browsing pack [MobilePk]
				"{44BBA840-CC51-11CF-AAFA-00AA00B6015C}", //Outlook Express
				"{CC2A9BA0-3BDD-11D0-821E-444553540000}", //Task Scheduler
				"{08B0E5C0-4FCB-11CF-AAA5-00401C608500}", //Microsoft virtual machine
				"{60B49E34-C7CC-11D0-8953-00A0C90347FF}", //Internet Explorer Branding
				"{03F998B2-0E00-11D3-A498-00104B6EB52E}", //Viewpoint (MetaStream?)
				"{0FDE1F56-0D59-4FD7-9624-E3DF6B419D0E}", //IE Readme
				"{10072CEC-8CC1-11D1-986E-00A0C955B42F}", //Vector Graphics Rendering (VML)
				"{1B00725B-C455-4DE6-BFB6-AD540AD427CD}", //???
				"{4278C270-A269-11D1-B5BF-0000F8051515}", //AdvAuth
				"{44BBA855-CC51-11CF-AAFA-00AA00B6015C}", //DirectDrawEx
				"{4F645220-306D-11D2-995D-00C04F98BBC9}", //Visual Basic Scripting Support
				"{5FD399C0-A70A-11D1-9948-00C04F98BBC9}", //General Setup
				"{630B1DA0-B465-11D1-9948-00C04F98BBC9}", //Windows Internet Explorer Browsing Enhancements
				"{6FAB99D0-BAB8-11D1-994A-00C04F98BBC9}", //MSN Authentication
				"{C9E9A340-D1F1-11D0-821E-444553540600}", //Fonts core
				"{D27CDB6E-AE6D-11CF-96B8-444553540000}", //Macromedia Flash
				"{E92B03AB-B707-11D2-9CBD-0000F87A369E}", //???
				"{47F67D00-9E55-11D1-BAEF-00C04FC2D130}", //AOL ART Image Format Support
				"{76C19B38-F0C8-11CF-87CC-0020AFEECF20}", //Arabic Text Display Support
				"{76C19B34-F0C8-11CF-87CC-0020AFEECF20}", //Chinese (Simplified) Text Display Support
				"{76C19B33-F0C8-11CF-87CC-0020AFEECF20}", //Chinese (traditional) Text Display Support
				"{76C19B36-F0C8-11CF-87CC-0020AFEECF20}", //Hebrew Text Display Support
				"{76C19B30-F0C8-11CF-87CC-0020AFEECF20}", //Japanese Text Display Support
				"{76C19B31-F0C8-11CF-87CC-0020AFEECF20}", //Korean Text Display Support
				"{76C19B50-F0C8-11CF-87CC-0020AFEECF20}", //Language Auto-Selection
				"{2A202491-F00D-11CF-87CC-0020AFEECF20}", //Macromedia Shockwave Director
				"{5945C046-LE7D-LLDL-BC44-00C04FD912BE}", //MSN Messenger Service
				"{76C19B32-F0C8-11CF-87CC-0020AFEECF20}", //Pan-European Text Display Support
				"{76C19B35-F0C8-11CF-87CC-0020AFEECF20}", //Thai Text Display Support
				"{3BF42070-B3B1-11D1-B5C5-0000F8051515}", //Uniscribe
				"{76C19B37-F0C8-11CF-87CC-0020AFEECF20}", //Vietnamese Text Display Support
				"{73FA19D0-2D75-11D2-995D-00C04F98BBC9}", //Web Folders
				"{0fde1f56-0d59-4fd7-9624-e3df6b419d0f}", //IEEX
				"{BEF6E001-A874-101A-8BBA-00AA00300CAB}", //MFC40
				"{18b6f603-bdc4-4eee-9598-d2a4d1375605}", //MDAC
				"{5945c046-1e7d-11d1-bc44-00c04fd912be}", //Messenger
				"{44BBA855-CC51-11CF-AAFA-00AA00B6015D}", //DirectX Mini
				"{44BBA855-CC51-11CF-AAFA-00AA00B6015F}", //DirectDraw EX
				"{9a2e4ab0-9a7e-11d2-9da1-00c04f98bbc9}", //Windows Media Player Codecs
				"{C9E9A340-D1F1-11D0-821E-444553540300}", //Fontsup
				"{F94C2DA4-708E-11d3-AFB2-00C04F6814C4}" //OAINST
			];

			length = clids.length;
			for (i = 0; i < length; i++) {
				//check whether user's machine supports this feature
				if (version = el.getComponentVersion(clids[i], "ComponentID")) {
					data.capabilities.push({
						id: clids[i],
						version: version
					});
				}
			}
		};


	return {
		start: start,
		getData: function () {
			return data;
		}
	};
});



/// File include: 'handlers/navhandler.js'

kl.registerHandler("nav", ["helpers", "utils"], function (helpers, utils) {
	var _sendTrigger = function(){},
		curUrl = "",
		nextUrl = "",
		urlChangeTimeout = 200,
		testTimer = null,
		historyLen = 0;

	function clickHandler(evt) {
		evt = evt || window.event;
		if( !evt )
			return;
		var elt = evt.srcElement || evt.target || evt.targetElement;
		if( elt && (elt.tagName || "").toLowerCase() === "a" && !!elt.href ){
			nextUrl = elt.href;
			collect();
			_sendTrigger();
		}
	}

	function enterHandler(evt) {
		evt = evt || window.event;
		if( !evt )
			return;

		var elt = evt.srcElement || evt.target || evt.targetElement,
			_key = evt.which || evt.keyCode;

		if( elt && ( _key === 13 || _key === 32 || _key === 0 ) ){
			var _tagName = (elt.tagName || "").toLowerCase();
			switch( _tagName ){
				case "a": clickHandler(evt); break;
			}
		}
	}

	function formHandler(evt) {
		evt = evt || window.event;
		if( !evt )
			return;

		var elt = evt.srcElement || evt.target || evt.targetElement;

		if( elt && (elt.tagName || "").toLowerCase() === "form" && !!elt.action ){
			nextUrl = elt.action;
			collect();
			_sendTrigger();
		}
	}

	function collect() {
		curUrl = window.location.href;
		historyLen = window.history.length;
	}

	function navEvtHandler() {
		collect();

		_sendTrigger();
	}

	function testUrl() {
		if(testTimer)
			window.clearTimeout(testTimer);

		if( window.location.href !== curUrl ){
			collect();
			_sendTrigger();
		}

		testTimer = window.setTimeout( utils.delegate( this, testUrl ), urlChangeTimeout );
	}

	function startHandler(_options) {
		_sendTrigger = _options.sendTrigger;
		helpers.dom.bind( "a", "onmousedown", clickHandler, true );
		helpers.dom.bind( "a", "onkeydown", enterHandler, true );
		helpers.dom.bind( "form", "onsubmit", formHandler, true );

		collect();

		if("onhashchange" in window )
			helpers.dom.bind( window, "hashchange", navEvtHandler );

		if("onpopstate" in window || "PopStateEvent" in window)
			helpers.dom.bind( window, "popstate", navEvtHandler );
		else
			testUrl.call(this);
	}

	return {
		"start": startHandler,
		"getData": function() {
			var _nextUrl = nextUrl;
			nextUrl = "";
			return {
				//"url": curUrl,
				//"historyLen": historyLen,
				"nextUrl": helpers.strHelper.maskNumbers( _nextUrl )
			};

		}
	};
});


	(function () {
		kl.init();
	})();
	
})(window, window.document);
