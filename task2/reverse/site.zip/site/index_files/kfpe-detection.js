;var KFP = KFP || {};
KFP.EndpointDetection = KFP.EndpointDetection || {};

KFP.EndpointDetection = function (presenceHandler, absenceHandler) {

	function detectActiveKasperskyProducts() {
		var productsV1 = detectActiveProductsWithApiV1();
		var productsV2 = detectActiveProductsWithApiV2();
		return productsV1.concat(productsV2);
	}

	function detectActiveProductsWithApiV1() {
		return window.KasperskyLab && KasperskyLab.getProductVersionInfo ?
			[convertV1toV2(KasperskyLab.getProductVersionInfo())] : [];
	}

	function convertV1toV2(product) {
		return {
			'productName': product.productName,
			'productVersion': product.productVersion,
			'productPPCSID': product.productPPCSID,
			'features': {
				'isSafeMoneyInstalled': product.isSafeMoneyInstalled,
				'isSafeMoneyProtectionEnabled': product.isSafeMoneyProtectionEnabled
			}
		};
	}

	function detectActiveProductsWithApiV2() {
		return window.KasperskyLab && KasperskyLab.getInstalledProducts ?
			KasperskyLab.getInstalledProducts() : [];
	}

	window.setTimeout(function () {
		var products = detectActiveKasperskyProducts();
		var hasActiveProtection = false;
		for (var i = 0; i < products.length; i++) {
			var p = products[i];
			if (p.features.isSafeMoneyInstalled && p.features.isSafeMoneyProtectionEnabled)
				hasActiveProtection = true;
		}
		if (hasActiveProtection && typeof (presenceHandler) === 'function')
			presenceHandler();
		else if (!hasActiveProtection && typeof (absenceHandler) === 'function')
			absenceHandler();
	}, 500);
};
