﻿(function ($, window) {
	$(function () {

		$('.js-lang-selector>li>a').on('click', function (event) {
			var now = new Date();
			var time = now.getTime();
			var expireTime = time + 1000 * 3600 * 24 * 365;
			now.setTime(expireTime);
			document.cookie = 'UserLocale=' + $(this).data('lang') + ';expires=' + now.toGMTString() + ';path=/';
			window.location = window.location.href;
			event.preventDefault();
		});
		
		WBank.checkEndpointInstalled();
	});

})(jQuery, window);

WBank = (function () {
	var userName = "";
	var loginDeferred = $.Deferred(),
		loginPromise = loginDeferred.promise();
	var phase = 0;

	function initLoginPromise(app, container) {
		loginDeferred = $.Deferred(),
		loginPromise = loginDeferred.promise();
			loginPromise = loginPromise.then(
				function (sessionId) {
					var form = $('#loginFormContainer form')
					form.find(".login-sess-id").val(sessionId);
					form.submit();
				if (!form.valid()){
					app.hideLoader(container);
				}
				},
				function (e) {
					$("loginFormContainer").find(".error-container").show().empty().html("Security error. Please contact our security manager.");
				}
			);
	}

	return ({
		_kfpBanklId: window.atoClientId,
		phase: phase,
		init: function () {
			var _this = this;
			$(function() {

			});
			return this;
		},
		addAuthCallback: function (fn) {
			$(this).on("onuserlogin", function (evt, success, username) { fn(success, username); });
		},

		showLoader: function (container) {
			$(container).addClass("data-loading");
		},

		hideLoader: function (container) {
			$(container).removeClass("data-loading");
		},

		checkEndpointInstalled: function () {
			KFP.EndpointDetection(null, this.noEndpointHandler);
		},

		hideDialog: function (dlg) {
			dlg.find("input[type=text],input[type=password],textarea").val('');
			dlg.modal('hide');
		},
		showVerificationPhase: function() {
			this.phase = 1;
			$("#verificationDialog").modal('show');
		},
		showLoginPhase: function () {
			this.phase = 0;

			$("#verification-phase").modal('hide');
		},
		noEndpointHandler: function () {
			if (
				userId &&
				((document.cookie || "").indexOf("obs-endpoint-test=done") == -1) &&
				((navigator.platform.toLowerCase().indexOf("win") !== -1) || (navigator.platform.toLowerCase().indexOf("mac") !== -1))
			) {
				$("#noEndpointDialog").modal("show");
				document.cookie = "obs-endpoint-test=done;path=/";
			}

			//$(".nav-download-tab").show();
			try { console.log("No Endpoint installed"); } catch (e) { }
		},

		tryLogin: function (container) {
			this.showLoader(container);
			userName = $("#UserName").val();
			if (this.phase == 0) {
			if (window.kfp && (typeof window.kfp.login_start) == "function") {
					window.kfp.login_start(window.atoClientId, "login")
					.done(function (sessionid) { loginDeferred.resolve(sessionid); })
					.fail(function (err) { loginDeferred.reject(err); });
				//loginPromise = loginPromise.then(function (a) { debugger; return  });
				//loginDeferred.resolve(userName);
				} else
				loginDeferred.resolve();
			} else {
				var form = $('#loginFormContainer form')
				var ocm = $('#verificationDialog .inpt-verification').val();
				form.find(".ocm").val(ocm);
				form.find(".phase").val(1);
				form.submit();
			}
		},

		setLoginSuccess: function (container, data) {
			var t = this;
			this.hideLoader(container);
			$(container).hide();
			$(this).trigger("onuserlogin", [true, userName]);
			
			if (data.Success == false) {
				initLoginPromise(t, container);
				$(container).show();
				t.hideLoader(container);
				if (data.Phase == 1) {
					t.showVerificationPhase();
					$(container).find(".error-container").show().empty();
				} else if (data.Phase == 2) {
					t.showLoginPhase();
					$(container).find(".error-container").show().empty().html("Access restricted. Please contact our tech support.");
				} else {
					t.showLoginPhase();
					$(container).find(".error-container").show().empty().html("Error ocured. Please contact our tech support.");
				}
			} else {
				window.setTimeout(function () {
					window.location.href = data.RedirectUrl;
				}, 100);
			}
		},

		setLoginFailed: function (container, data) {
			this.hideLoader(container);
			$(container).show();
			initLoginPromise();
			if (data && data["Error"]) {
				$(container).find(".error-container").show().empty().html(data.Error.join("<br/>"));
				$(this).trigger("onuserlogin", [false, userName]);
			}
		}
	}).init();
})();